<?php
session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: login.html");
    exit();
}
include 'conexion.php';

echo "<h2>Bienvenido " . $_SESSION['usuario'] . "</h2>";
echo "<a href='logout.php'>Cerrar sesión</a><hr>";

$result = $conn->query("SELECT * FROM productos");

while ($row = $result->fetch_assoc()) {
    echo "<div>{$row['nombre']} - {$row['precio']}€ 
          <a href='compra.php?ref={$row['referencia']}'>Comprar</a></div>";
}
?>
