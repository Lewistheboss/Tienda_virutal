<?php
include 'conexion.php';

$usuario = $_POST['usuario'];
$contrasena = password_hash($_POST['contrasena'], PASSWORD_DEFAULT);

$stmt = $conn->prepare("INSERT INTO usuarios (usuario, contrasena) VALUES (?, ?)");
$stmt->bind_param("ss", $usuario, $contrasena);
$stmt->execute();

$stmt2 = $conn->prepare("INSERT INTO clientes (nombre, apellidos, correo, fecha_nacimiento, genero)
    VALUES (?, ?, ?, ?, ?)");
$stmt2->bind_param("sssss", $_POST['nombre'], $_POST['apellidos'], $_POST['correo'],
    $_POST['fecha_nacimiento'], $_POST['genero']);
$stmt2->execute();

header("Location: login.html");
?>
