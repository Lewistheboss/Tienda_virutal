<?php
session_start();
include 'conexion.php';

$usuario = $_POST['usuario'];
$contrasena = $_POST['contrasena'];

$sql = "SELECT contrasena FROM usuarios WHERE usuario = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $usuario);
$stmt->execute();
$stmt->bind_result($hash);
$stmt->fetch();

if (password_verify($contrasena, $hash)) {
    $_SESSION['usuario'] = $usuario;
    header("Location: tienda.php");
} else {
    echo "Usuario o contraseña incorrectos.";
}
?>
