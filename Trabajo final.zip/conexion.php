<?php
$host = "localhost";
$user = "root";
$pass = ""; // Tu contraseña de MySQL (si tienes)
$db = "tienda_virtual";

$conn = new mysqli($host, $user, $pass, $db);
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}
?>
