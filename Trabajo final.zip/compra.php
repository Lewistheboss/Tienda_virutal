<?php
session_start();
include 'conexion.php';

$usuario = $_SESSION['usuario'];
$ref = $_GET['ref'];

$stmt = $conn->prepare("INSERT INTO compras (usuario, referencia) VALUES (?, ?)");
$stmt->bind_param("ss", $usuario, $ref);
$stmt->execute();

echo "Compra realizada con éxito.<br><a href='tienda.php'>Volver a la tienda</a>";
?>
